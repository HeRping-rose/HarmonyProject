void main() {
  // 需求：准备高考成绩，如果分数大于等于700分，则输出 '恭喜考入黑马程序员'，反之，则输出 '继续努力'
  // 思考：以下代码可以简化吗？
  int score1 = 699;
  if (score1 >= 700) {
    print('恭喜考入黑马程序员');
  } else {
    print('继续努力');
  }

  // 1. 使用三元运算符简化if双语句：条件表达式 ? 表达式1 : 表达式2

  // 2. 思考：以下代码适合使用三元运算符改写吗？
  int score2 = 88;
  if (score2 >= 90) {
    print('优秀');
  } else if (score2 >= 80) {
    print('良好');
  } else if (score2 >= 60) {
    print('中等');
  } else {
    print('不及格');
  }
}
