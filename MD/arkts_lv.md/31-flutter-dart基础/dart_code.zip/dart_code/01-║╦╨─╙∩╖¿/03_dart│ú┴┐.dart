void main() {
  // 1. final和const声明常量

  // 2. final和const相同点: 都不能改值

  // 3. final和const不同点
}
