void main() {
  // 准备购物车数据
  // List carts = [
  //   {"count": 2, "price": 10.0, "selected": true},
  //   {"count": 1, "price": 30.0, "selected": false},
  //   {"count": 5, "price": 20.0, "selected": true}
  // ];
}
